<?php

if(!isset($_SESSION['page_a_visited'])){
        header("Location: http://nullrefer.com/?https://www.google.com/");
		die();

}
?>